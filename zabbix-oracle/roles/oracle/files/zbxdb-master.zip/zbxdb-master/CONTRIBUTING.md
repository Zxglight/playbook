👍🎉 First off, thanks for taking the time to contribute! 🎉👍

If you  see items in any database that should be monitored and is not included yet, add the SQL to the apropiate file and share it. The items that are to be part of the zbxdb distribution should not be application specific but general for the database.

Exception handling is not the  easiest, given  the fact that many drivers have subtle differences in how they handle certain problems. Some  handle network timeouts, some don't ....  so if you hit some problems and were able to fix that with smarter/extra exception handling for the driver you used, please share it.
